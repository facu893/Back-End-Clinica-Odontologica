package com.dh.clinica.model;

public enum AppUserRole {
    USER,ADMIN
}
