package com.dh.clinica.service;

public enum AppUsuarioRole {
    USER,ADMIN
}